import java.io.BufferedReader;
import java.io.IOException;

public class ControlConnectionListener extends Thread{
	BufferedReader in;
    String command;
	
	public ControlConnectionListener(BufferedReader in) {
		this.in = in;
        this.command = "  ";
	}

	public void updateCommand(String command){
        this.command = command;
    }
	
	public void run() {
		String output;
		
		try {

			while((output=in.readLine())!=null){
					System.out.println(output);
    				if(output.contains("220 ") || output.contains("226 ") || output.contains("230 ")){
                        System.out.print("csftp> ");

                    }else if(output.contains("550 ")){
                        String[] commandArgs = command.split(" ");
                        System.err.println("0x38E Access to local file "+commandArgs[2]+" denied. ");
                        continue;
                    }else if(output.matches(".*\\(\\d*,\\d*,\\d*,\\d*,\\d*,\\d*\\).*")) {
						String[] pasvAdr = Utility.extractAdr(output);

						new DataConnection(pasvAdr[0], Integer.parseInt(pasvAdr[1])).start();
					}					
			}
			
		}catch(IOException e){
			System.err.println("IOException");
			System.exit(1);
		}

	}
}
